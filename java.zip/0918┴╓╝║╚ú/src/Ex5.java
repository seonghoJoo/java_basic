
public class Ex5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 2;
		int b = 3;
		System.out.println(++a==b && --a!=b); // 3 == 3 && 2 !=3 // true
		System.out.println(a++==b && --a!=b);	// 2==b && false
	}

}
