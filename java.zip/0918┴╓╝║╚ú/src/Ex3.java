
public class Ex3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char a = 'A';
		int b = 5;
		int c = a+b;
		System.out.println(c);//70
	}

}
