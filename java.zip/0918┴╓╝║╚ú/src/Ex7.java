
public class Ex7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=2;i<12;i++) {
			if(i/2==3) {// 6 -> 3 7 -> 3.5 
				System.out.println(i+ "입니다");
			}
		}
	}

}
