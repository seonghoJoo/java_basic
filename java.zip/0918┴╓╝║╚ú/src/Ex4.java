
public class Ex4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		byte b = 3;
		boolean a = b!=3;
		System.out.println(!a);//true
	}

}
