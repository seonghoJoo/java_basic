
public class Ex6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 3;
		if(--a==3 || a==2) {	//2 ==3 a==2 맞음
			System.out.println("맞음");
		}else {
			System.out.println("틀림");
			
		}
	}

}
