
public class ScEx4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=0;i<5;i++) {
			for(int j=0;j<=i;j++) {
				System.out.print("* ");
			}// for j end
			System.out.println();
		}// for i end
	}

}
