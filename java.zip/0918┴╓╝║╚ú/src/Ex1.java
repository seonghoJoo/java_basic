
public class Ex1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		byte a = 1;
		short b = 2;
		short c = (short)(a+b);
		// a + b 의 결과값은 INT 형이 지만 강제 형변환이 없다
		System.out.println(c);
	}

}
