
public class Ex2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a  = 2;
		int b = 3;
		int c = ++a + b++; // 3+3
		System.out.println(a);	//3
		System.out.println(b);	//4
		System.out.println(c);	//6 
	}
}
