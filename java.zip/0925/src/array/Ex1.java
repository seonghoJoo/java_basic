package array;

public class Ex1 {

	public static void main(String[] args) {
		
		int[] a = new int[3];
		a[1] = 3;
		a[2] = a[0];
		
		boolean[] b = new boolean[4];

		boolean[] c = {true,false};
		
	
	}
}
