package control;

public class WhileEx2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 2단 출력
		int i=1;
		while(i<10) {
			System.out.println("2 * " + i + " = " + 2*i++);
		}//while end
	}//main end
}// WhileEx2 end
