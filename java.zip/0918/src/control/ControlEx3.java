package control;

public class ControlEx3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 	제어문
		 	- 분기문 : if , switch
		 	- 반복문 : for, while
		 	for문 문법
		 	for (초기식;조건식;증감식){
				조건식이 true일 동안 반복구문 수행
		 		
		 		반복구문
		 	}
		 		
		 */
		
		for( int i = 1; i < 10 ; i++ ) {
			System.out.println("8 * " + i + " = "+8*i );
			
		}
		
		
	}//main() end

}// class ControlEx3 end
