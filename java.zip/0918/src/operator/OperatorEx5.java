package operator;

public class OperatorEx5 {
	public static void main(String[] args) {
		
		/* 
		 * 
		 * 		논리 연산자
		 * 		논리곱 : &&
		 * 		논리합 : ||
		 * 		논리값이 있어야 함
		 * 
		 
		 */
		
	
	}//main() end

}//OperatorEx5 end
