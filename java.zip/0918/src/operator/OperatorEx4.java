package operator;

public class OperatorEx4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 		삼항연산자
		 		변수 = 논리값 ? 값1 : 값2;
		 
		 		논리값이 true 면 값1이 변수에 대입
		 		논리값이 false면 값2가 변수에 대입
		 		int a = true? 4 : 7;
		 */
		int a;
		if(3==5) {
			a = 4;
		}else {
			a = 7;
		}
	}

}
