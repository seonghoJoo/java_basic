package test;

public class B {
	private int a;
	boolean b;
	protected B c;
	public String d;
}
